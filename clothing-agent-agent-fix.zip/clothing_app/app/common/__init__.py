"""Shared application-level utilities."""
