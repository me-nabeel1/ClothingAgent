"""Agent foundation tests."""
